<?php
//SSO Studentsite UG
//jibrilhp

date_default_timezone_set("Asia/Jakarta");
header("content-type: application/json");

function readStrLine($str, $n) {
  $lines = preg_split("/\r\n|\n|\r/", $str);
 
  
  return $lines[$n-1];
}

function hilangkan($req) {
  $filternya = array("NPM:","Username:");
  for($i=0;$i<count($filternya);$i++) {
    $req = str_ireplace($filternya[$i],"",$req);
  }
  return $req;
}



function connect_sso($username,$password,$user_agent) {
  // $user_agent= "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/534.57.2 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2. Your User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:12.0) Gecko/20100101 Firefox/" . rand(57,73) . "1.20";
  $ambil = curl_init();
  CURL_SETOPT($ambil,CURLOPT_URL,"https://studentsite.gunadarma.ac.id/index.php/site/login");
  CURL_SETOPT($ambil,CURLOPT_USERAGENT,$user_agent);
  CURL_SETOPT($ambil,CURLOPT_POST,True);
  CURL_SETOPT($ambil,CURLOPT_POSTFIELDS,"username=".$username."&password=" . $password);
  CURL_SETOPT($ambil,CURLOPT_RETURNTRANSFER,True);
  CURL_SETOPT($ambil,CURLOPT_FOLLOWLOCATION,True);
  CURL_SETOPT($ambil,CURLOPT_COOKIEFILE,"cook.txt");
  CURL_SETOPT($ambil,CURLOPT_COOKIEJAR,"cook.txt");
  CURL_SETOPT($ambil,CURLOPT_CONNECTTIMEOUT,100);
  CURL_SETOPT($ambil,CURLOPT_TIMEOUT,100);
  $exec = curl_exec($ambil);
  

  $npm = hilangkan(str_replace(" ","",strip_tags(readStrLine($exec,86)))); //npm

  
  $ting2 = hilangkan(str_replace(" ","",strip_tags(readStrLine($exec,88)))); //username
 
  //Get photos studentsite..
  // CURL_SETOPT($ambil,CURLOPT_URL,"http://studentsite.gunadarma.ac.id/index.php/foto/display/1");
  // CURL_SETOPT($ambil,CURLOPT_USERAGENT,$user_agent);

  $exec = curl_exec($ambil);
  // $foto = base64_encode($exec);

  if (stripos($npm,"Login") !== false) {
    //jika username kosong maka tidak terjadi login..
    $outp = array("status"=>"failed","output"=>$exec);
    $outp = json_encode($outp);
  } else {
  //Get full name ..
    CURL_SETOPT($ambil,CURLOPT_URL,"https://studentsite.gunadarma.ac.id/index.php/foto/index");
    CURL_SETOPT($ambil,CURLOPT_USERAGENT,$user_agent);

    $name = curl_exec($ambil);
    
    $name = readStrLine($name,307);
    $name2 = explode(">",$name);
    $name2 = explode("<",$name2[19]);
    $nama = ucwords(strtolower($name2[0]));
    $email = $username.'@student.gunadarma.ac.id';
    $angkatan = '20'.substr($npm,3,2);

    //$outp = array("status"=>"success","npm"=>$npm,"username"=>$ting2,"nama"=>$nama,"foto"=>$foto);
    // $outp = array("status"=>"success","npm"=>$npm,"username"=>$ting2,"email"=>$email,"angkatan"=>$angkatan,"nama"=>$nama,"foto"=>$foto);
    $outp = array("status"=>"success","npm"=>$npm,"username"=>$username,"email"=>$email,"angkatan"=>$angkatan,"nama"=>$nama);
    $outp = json_encode($outp);
  }
  
  return $outp;
}

if(isset($_POST['a']) && isset($_POST['p']) && isset($_POST['z'])) {
  if (file_exists("cook.txt")) {
    unlink("cook.txt");
  }
echo connect_sso($_POST['a'],$_POST['p'],$_POST['z']);
} else if (isset($_GET['a'])) {
echo connect_sso($_GET['a'],$_GET['p'],"Mozilla/6.0 (Macintosh; Intel Mac OS X 10_10_4)");
} else {
  echo "hai jibs! @jibrilhp";
}
?>
